# Natural Mattress — Shopify Theme

## Dosya Yapısı

```
shopify-theme/
├── layout/
│   └── theme.liquid          ← Ana layout (nav + footer tüm sayfalarda)
├── templates/
│   ├── index.liquid           ← Ana sayfa (hero + stats + sections)
│   └── product.liquid         ← Ürün sayfası (tam Liquid dinamik)
├── sections/
│   └── fabric-feature.liquid  ← Örgü kumaş bölümü (Customizer'dan düzenlenebilir)
├── assets/
│   ├── natural.css            ← Tüm stil (mevcut tasarımdan)
│   ├── bedroom.jpg            ← Hero görseli (316_2x.jpg)
│   ├── wool.jpg               ← Yün görseli (21_2x.jpg)
│   ├── cotton.jpg             ← Pamuk görseli (20_2x.jpg)
│   └── fabric.jpg             ← Örgü kumaş görseli (106_2x.jpg)
├── config/
│   └── settings_schema.json   ← Shopify Customizer ayarları
└── locales/
    ├── en.default.json        ← İngilizce çeviriler
    └── de.json                ← Almanca çeviriler
```

## Shopify'a Yükleme Adımları

### 1. Görselleri assets klasörüne ekle
Yüklediğin görsel dosyalarını şu isimlerle `assets/` klasörüne koy:
- `316_2x.jpg` → `assets/bedroom.jpg`
- `21_2x.jpg`  → `assets/wool.jpg`
- `20_2x.jpg`  → `assets/cotton.jpg`
- `106_2x.jpg` → `assets/fabric.jpg`

### 2. ZIP dosyası oluştur
```bash
cd shopify-theme
zip -r natural-mattress-theme.zip .
```

### 3. Shopify'a yükle
- Shopify Admin → Online Store → Themes
- "Add theme" → "Upload zip file"
- ZIP'i seç ve yükle

### 4. Ürün ayarları
Shopify Admin → Products → Ürünü oluştur:
- **Title**: The Natural Mattress
- **Variants**: Single (S1), Double (S2), King Size (D1), Super King (D2)
  - Her variant için fiyat ve stok gir
- **Metafields** (opsiyonel — katman detayları için):
  - `custom.subtitle`
  - `custom.layer_1_title`, `custom.layer_1_body`, `custom.layer_1_cert`
  - `custom.layer_2_title`, `custom.layer_2_body`, `custom.layer_2_cert`
  - `custom.layer_3_title`, `custom.layer_3_body`, `custom.layer_3_cert`

### 5. Shopify Payments / Stripe
- Shopify Admin → Settings → Payments
- "Shopify Payments" seç (Stripe altyapısını kullanır)
- Desteklenen para birimleri: GBP ve EUR

### 6. Çok dil
- Shopify Admin → Settings → Languages
- "Add language" → Almanca (de) ekle
- `locales/de.json` dosyası otomatik çevirileri sağlar

### 7. Çok para birimi
- Shopify Admin → Settings → Markets
- UK → GBP, EU ülkeleri → EUR

## Customizer'dan Düzenlenebilir Alanlar
Shopify Admin → Online Store → Themes → Customize:
- Hero görseli, başlık ve metin
- Accent rengi (sage yeşil)
- Örgü kumaş bölümü içerikleri
- Teslimat ülkeleri listesi
- Twitter/X handle

## Stripe Ödeme Notu
Shopify Payments = Stripe altyapısı üzerinde çalışır.
Ayrı Stripe entegrasyonu gerekmez.
